package interactive;

import java.util.Scanner;

public class InputManager {
	
	private static final Scanner input = new Scanner(System.in);
	
	public static String readString() {
		return input.next();
	}
	
	public static int readInt() {
		return input.nextInt();
	}

}
