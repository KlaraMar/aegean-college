package forms;

import interactive.InputManager;

public class Form {

	public static void main(String[] args) {
	    System.out.print("Type your name: ");
	    String name = InputManager.readString();
	    System.out.println("Your name is " + name);
	    
	    System.out.print("Type your age: ");
	    int age = InputManager.readInt();
	    System.out.println("Your age is " + age);

	    System.out.print("Type your email address: ");
	    String email = InputManager.readString();
	    System.out.println("Your email address is " + email);
	    
	    System.out.print("Type your favorite number: ");
	    int fn = InputManager.readInt();
	    System.out.println("Your favorite number is " + fn);
	}

}
